"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { apiMe } from "@/lib/api";
import { useAuth } from "@/context/AuthContext";

const roleLabel: Record<string, string> = {
  admin: "Administrador", profissional: "Profissional", academico: "Acadêmico",
  supervisor: "Supervisor", paciente: "Paciente", responsavel: "Responsável Legal"
};

export default function PerfilPage() {
  const { user, logout } = useAuth();
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) { window.location.href = "/login"; return; }
    apiMe().then(setProfile).catch(console.error).finally(() => setLoading(false));
  }, [user]);

  if (loading || !profile) return (
    <div className="min-h-screen bg-sinergya-background flex items-center justify-center">
      <p className="text-slate-400 text-sm">Carregando...</p>
    </div>
  );

  function goBack() {
    const role = user?.role ?? "";
    if (role === "admin") window.location.href = "/admin";
    else if (role === "paciente" || role === "responsavel") window.location.href = "/paciente";
    else window.location.href = "/patient/1";
  }

  return (
    <main className="min-h-screen bg-sinergya-background">
      <header className="bg-sinergya-dark text-white px-8 py-4 flex items-center justify-between">
        <button onClick={goBack} className="flex items-center gap-2 text-white/60 hover:text-white transition text-sm">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <polyline points="15 18 9 12 15 6"/>
          </svg>
          Voltar
        </button>
        <Image src="/logo.png" alt="Sinergya" width={120} height={35} />
        <button onClick={logout} className="text-white/40 hover:text-white transition text-xs flex items-center gap-1.5">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
            <polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>
          </svg>
          Sair
        </button>
      </header>

      <div className="max-w-2xl mx-auto px-8 py-10">
        <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
          {/* Header do perfil */}
          <div className="px-8 py-8 text-white" style={{ background: "linear-gradient(135deg, #0F172A, #1e293b)" }}>
            <div className="flex items-center gap-5">
              <div className="w-16 h-16 rounded-2xl bg-sinergya-green/20 flex items-center justify-center text-2xl font-bold text-sinergya-green">
                {profile.name?.[0]?.toUpperCase() ?? "?"}
              </div>
              <div>
                <h1 className="text-xl font-bold">{profile.name}</h1>
                <p className="text-white/50 text-sm mt-0.5">{roleLabel[profile.role] ?? profile.role}</p>
                <span className={`mt-2 inline-block px-2 py-0.5 rounded-full text-xs font-medium ${profile.lgpd_consent ? "bg-sinergya-green/20 text-sinergya-green" : "bg-red-500/20 text-red-400"}`}>
                  {profile.lgpd_consent ? "✓ LGPD aceita" : "✗ LGPD pendente"}
                </span>
              </div>
            </div>
          </div>

          {/* Dados */}
          <div className="px-8 py-6 space-y-4">
            <h2 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Dados da conta</h2>

            {[
              { label: "Nome completo", value: profile.name },
              { label: "Email", value: profile.email },
              { label: "Perfil", value: roleLabel[profile.role] ?? profile.role },
              { label: "Status", value: profile.is_active ? "Ativo" : "Inativo" },
              ...(profile.specialty ? [{ label: "Especialidade", value: profile.specialty }] : []),
              ...(profile.council_number ? [{ label: "Conselho", value: profile.council_number }] : []),
              ...(profile.course ? [{ label: "Curso", value: profile.course }] : []),
              ...(profile.institution ? [{ label: "Instituição", value: profile.institution }] : []),
            ].map(({ label, value }) => (
              <div key={label} className="flex items-center justify-between py-3 border-b border-slate-100 last:border-0">
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">{label}</span>
                <span className="text-sm text-slate-700 font-medium">{value}</span>
              </div>
            ))}

            <div className="flex items-center justify-between py-3 border-b border-slate-100">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Membro desde</span>
              <span className="text-sm text-slate-700 font-medium">
                {new Date(profile.created_at).toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" })}
              </span>
            </div>
          </div>

          <div className="px-8 pb-8">
            <p className="text-xs text-slate-400 text-center">
              Para alterar seus dados, entre em contato com o administrador da plataforma.
            </p>
          </div>
        </div>
      </div>
    </main>
  );
}