"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { apiAdminStats, apiAdminUsers, apiAdminLogs, apiLogout } from "@/lib/api";
import { useAuth } from "@/context/AuthContext";

type AdminTab = "stats" | "users" | "logs";

export default function AdminPage() {
  const { user, logout } = useAuth();
  const [activeTab, setActiveTab] = useState<AdminTab>("stats");
  const [stats, setStats] = useState<any>(null);
  const [users, setUsers] = useState<any[]>([]);
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([apiAdminStats(), apiAdminUsers()])
      .then(([s, u]) => { setStats(s); setUsers(u); })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (activeTab === "logs" && logs.length === 0) {
      apiAdminLogs().then(setLogs).catch(console.error);
    }
  }, [activeTab]);

  function formatDate(iso: string) {
    return new Date(iso).toLocaleDateString("pt-BR", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
  }

  const roleLabel: Record<string, string> = {
    admin: "Admin", profissional: "Profissional", academico: "Acadêmico",
    supervisor: "Supervisor", paciente: "Paciente", responsavel: "Responsável"
  };

  const roleColor: Record<string, string> = {
    admin: "bg-red-100 text-red-700",
    profissional: "bg-sinergya-blue/10 text-sinergya-blue",
    academico: "bg-purple-100 text-purple-700",
    supervisor: "bg-amber-100 text-amber-700",
    paciente: "bg-sinergya-green/10 text-sinergya-green",
    responsavel: "bg-slate-100 text-slate-600",
  };

  return (
    <main className="min-h-screen bg-sinergya-background">
      {/* HEADER */}
      <header className="bg-sinergya-dark text-white px-8 py-4 flex items-center justify-between">
        <Image src="/logo.png" alt="Sinergya" width={140} height={40} />
        <div className="flex items-center gap-4">
          <div className="text-right">
            <p className="text-sm font-medium">{user?.name}</p>
            <p className="text-xs text-white/50">Administrador</p>
          </div>
          <button onClick={logout} className="text-white/40 hover:text-white transition">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
              <polyline points="16 17 21 12 16 7"/>
              <line x1="21" y1="12" x2="9" y2="12"/>
            </svg>
          </button>
        </div>
      </header>

      <div className="px-8 py-6 max-w-6xl mx-auto">
        <h1 className="text-2xl font-bold text-sinergya-dark mb-6">Painel Administrativo</h1>

        {/* TABS */}
        <div className="flex gap-1 border-b border-slate-200 mb-6 bg-white rounded-t-xl px-4">
          {([["stats", "Indicadores"], ["users", "Usuários"], ["logs", "Auditoria"]] as [AdminTab, string][]).map(([key, label]) => (
            <button key={key} onClick={() => setActiveTab(key)}
              className={`px-4 py-3 text-sm font-medium border-b-2 transition-all ${
                activeTab === key ? "border-sinergya-green text-sinergya-green" : "border-transparent text-slate-500 hover:text-slate-700"
              }`}>
              {label}
            </button>
          ))}
        </div>

        {loading && <p className="text-slate-400 text-sm">Carregando...</p>}

        {/* STATS */}
        {activeTab === "stats" && stats && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: "Usuários ativos", value: stats.active_users, color: "text-sinergya-green" },
                { label: "Total usuários", value: stats.total_users, color: "text-sinergya-blue" },
                { label: "Pacientes", value: stats.total_patients, color: "text-amber-500" },
                { label: "Mensagens", value: stats.total_messages, color: "text-purple-500" },
              ].map((s) => (
                <div key={s.label} className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
                  <p className="text-xs text-slate-400 mb-1">{s.label}</p>
                  <p className={`text-3xl font-bold ${s.color}`}>{s.value}</p>
                </div>
              ))}
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
              <h3 className="text-sm font-semibold text-slate-700 mb-4">Usuários por perfil</h3>
              <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
                {Object.entries(stats.users_by_role ?? {}).map(([role, count]: any) => (
                  <div key={role} className="text-center">
                    <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium mb-1 ${roleColor[role] ?? "bg-slate-100 text-slate-600"}`}>
                      {roleLabel[role] ?? role}
                    </span>
                    <p className="text-lg font-bold text-sinergya-dark">{count}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* USERS */}
        {activeTab === "users" && (
          <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  {["Nome", "Email", "Perfil", "Status", "LGPD"].map((h) => (
                    <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {users.map((u: any) => (
                  <tr key={u.id} className="hover:bg-slate-50 transition">
                    <td className="px-4 py-3 font-medium text-sinergya-dark">{u.name}</td>
                    <td className="px-4 py-3 text-slate-500">{u.email}</td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${roleColor[u.role] ?? "bg-slate-100 text-slate-600"}`}>
                        {roleLabel[u.role] ?? u.role}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${u.is_active ? "bg-green-100 text-green-700" : "bg-red-100 text-red-600"}`}>
                        {u.is_active ? "Ativo" : "Inativo"}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-xs ${u.lgpd_consent ? "text-sinergya-green" : "text-red-500"}`}>
                        {u.lgpd_consent ? "✓ Sim" : "✗ Não"}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* LOGS */}
        {activeTab === "logs" && (
          <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  {["Ação", "Perfil", "Entidade", "Detalhe", "Data"].map((h) => (
                    <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {logs.length === 0 && (
                  <tr><td colSpan={5} className="px-4 py-8 text-center text-slate-400 text-xs">Nenhum log ainda.</td></tr>
                )}
                {logs.map((l: any) => (
                  <tr key={l.id} className="hover:bg-slate-50 transition">
                    <td className="px-4 py-3 font-medium text-sinergya-dark font-mono text-xs">{l.action}</td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${roleColor[l.user_role] ?? "bg-slate-100 text-slate-600"}`}>
                        {roleLabel[l.user_role] ?? l.user_role}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-slate-500 text-xs">{l.entity}</td>
                    <td className="px-4 py-3 text-slate-400 text-xs truncate max-w-xs">{l.detail}</td>
                    <td className="px-4 py-3 text-slate-400 text-xs">{formatDate(l.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </main>
  );
}