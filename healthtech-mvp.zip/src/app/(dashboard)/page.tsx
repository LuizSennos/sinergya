"use client";

import { useEffect } from "react";
import { apiGetPatients } from "@/lib/api";
import { useAuth } from "@/context/AuthContext";

export default function DashboardPage() {
  const { user, loading } = useAuth();

useEffect(() => {
  if (loading) return;
  if (!user) { window.location.href = "/login"; return; }
  if (user.role === "admin") { window.location.href = "/admin"; return; }
  if (user.role === "paciente" || user.role === "responsavel") { window.location.href = "/paciente"; return; }
  // profissional/academico/supervisor → redireciona pro primeiro paciente
  apiGetPatients()
    .then((patients) => {
      if (patients && patients.length > 0) {
        window.location.href = `/patient/${patients[0].id}`;
      }
    })
    .catch(() => { window.location.href = "/login"; });
}, [user, loading]);}